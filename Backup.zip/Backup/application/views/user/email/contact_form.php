<body>
	<h5>Hai admin,</h5>
	<table border="1">
	<tr>
		<th>Name</th>
		<th>Email ID</th>
		<th>Message</th>
	</tr>
	
	<tr>
	<td><?=$name?></td>
	<td><?=$email?></td>
	<td><?=$message?></td>
	</tr>
	</table>
</body>